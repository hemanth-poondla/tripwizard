export default function LoadingSpinner() {
  return <div className="spinner"></div>;
}