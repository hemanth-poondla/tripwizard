export function truncateTo2Decimals(value) {
  return Math.floor(value * 100) / 100;
}
